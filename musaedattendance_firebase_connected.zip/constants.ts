import type { Student } from './types';

export const GRADES = ['السادس', 'السابع', 'الثامن', 'التاسع'];
export const CLASSROOMS = ['1', '2', '3', '4', '5', '6'];
export const PERIODS = [1, 2, 3, 4, 5, 6, 7];
export const ADMIN_PASSWORD = 'ADMIN123';

// This data is used to seed localStorage if it's empty.
// The main source of truth for student data will be localStorage itself.
export const INITIAL_STUDENTS_DATA: Student[] = [
  // --- Grade 6 ---
  { id: '6-1-01', name: 'أحمد عبدالله', grade: 'السادس', classroom: '1' },
  { id: '6-1-02', name: 'محمد خالد', grade: 'السادس', classroom: '1' },
  { id: '6-1-03', name: 'علي حسن', grade: 'السادس', classroom: '1' },
  { id: '6-2-01', name: 'يوسف محمود', grade: 'السادس', classroom: '2' },
  { id: '6-2-02', name: 'عمر أحمد', grade: 'السادس', classroom: '2' },
  // --- Grade 7 ---
  { id: '7-1-01', name: 'عبدالرحمن سعيد', grade: 'السابع', classroom: '1' },
  { id: '7-1-02', name: 'سلمان فهد', grade: 'السابع', classroom: '1' },
  { id: '7-3-01', name: 'جاسم محمد', grade: 'السابع', classroom: '3' },
  // --- Grade 8 ---
  { id: '8-1-01', name: 'مشاري حمد', grade: 'الثامن', classroom: '1' },
  { id: '8-4-01', name: 'نواف طلال', grade: 'الثامن', classroom: '4' },
  { id: '8-4-02', name: 'راشد علي', grade: 'الثامن', classroom: '4' },
  // --- Grade 9 ---
  { id: '9-1-01', name: 'حمد عيسى', grade: 'التاسع', classroom: '1' },
  { id: '9-2-01', name: 'سعود عبدالعزيز', grade: 'التاسع', classroom: '2' },
  { id: '9-2-02', name: 'جابر صباح', grade: 'التاسع', classroom: '2' },
];