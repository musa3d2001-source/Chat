
// pages/AttendancePage.tsx
import React, { useState } from "react";
import { useAttendanceData } from "../hooks/useAttendanceData";

const AttendancePage = () => {
  const [studentId, setStudentId] = useState("");
  const [studentName, setStudentName] = useState("");
  const [grade, setGrade] = useState("");
  const [classroom, setClassroom] = useState("");

  const { attendance, addRecord, loading } = useAttendanceData();

  const handleAdd = () => {
    if (!studentId || !studentName || !grade || !classroom) return;

    const record = {
      studentId,
      studentName,
      grade,
      classroom,
      date: new Date().toISOString().split("T")[0],
    };

    addRecord(record);

    // reset fields
    setStudentId("");
    setStudentName("");
    setGrade("");
    setClassroom("");
  };

  return (
    <div>
      <h2>تسجيل الحضور</h2>

      <input placeholder="الرقم" value={studentId} onChange={(e) => setStudentId(e.target.value)} />
      <input placeholder="الاسم" value={studentName} onChange={(e) => setStudentName(e.target.value)} />
      <input placeholder="الصف" value={grade} onChange={(e) => setGrade(e.target.value)} />
      <input placeholder="الفصل" value={classroom} onChange={(e) => setClassroom(e.target.value)} />
      <button onClick={handleAdd}>تسجيل</button>

      {loading ? <p>جاري التحميل...</p> : (
        <ul>
          {attendance.map((record, index) => (
            <li key={index}>{record.studentName} - {record.grade} / {record.classroom}</li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AttendancePage;
