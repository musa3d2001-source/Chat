
// pages/AdminPage.tsx
import React, { useEffect, useState } from "react";
import { getFirestore, collection, getDocs } from "firebase/firestore";

const AdminPage = () => {
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      const db = getFirestore();
      const snapshot = await getDocs(collection(db, "attendance"));
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setRecords(data);
      setLoading(false);
    };

    loadData();
  }, []);

  const groupedByDate = records.reduce((acc, rec) => {
    const date = rec.date || "غير محدد";
    acc[date] = acc[date] || [];
    acc[date].push(rec);
    return acc;
  }, {} as any);

  return (
    <div>
      <h2>تقارير الغياب - المدير</h2>
      {loading ? <p>جارٍ التحميل...</p> : (
        Object.entries(groupedByDate).map(([date, items]: any) => (
          <div key={date}>
            <h3>{date}</h3>
            <ul>
              {items.map((item: any) => (
                <li key={item.id}>
                  الطالب: {item.studentName} - الصف: {item.grade} - الفصل: {item.classroom} - الحصة: {item.period}
                </li>
              ))}
            </ul>
          </div>
        ))
      )}
      <button onClick={() => window.print()}>🖨️ طباعة التقرير</button>
    </div>
  );
};

export default AdminPage;
