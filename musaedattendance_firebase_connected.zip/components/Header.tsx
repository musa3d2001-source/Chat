import React from 'react';
import { Icon } from './Icon';

interface HeaderProps {
  activePage: 'attendance' | 'reports' | 'settings';
  onNavigate: (page: 'attendance' | 'reports' | 'settings') => void;
}

export const Header: React.FC<HeaderProps> = ({ activePage, onNavigate }) => {
  const NavLink: React.FC<{
    page: 'attendance' | 'reports' | 'settings';
    iconName: 'list' | 'chart' | 'cog';
    text: string;
  }> = ({ page, iconName, text }) => {
    const isActive = activePage === page;
    return (
      <button
        onClick={() => onNavigate(page)}
        className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-semibold transition-colors duration-200 ${
          isActive
            ? 'bg-blue-600 text-white'
            : 'text-gray-600 hover:bg-gray-200'
        }`}
      >
        <Icon name={iconName} className="w-5 h-5" />
        {text}
      </button>
    );
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center gap-2">
            <div className="bg-blue-600 p-2 rounded-lg">
                <Icon name="check" className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-800">نظام إدارة الحضور</h1>
        </div>
        <nav className="flex items-center gap-2 p-1 bg-gray-100 rounded-lg">
          <NavLink page="attendance" iconName="list" text="تسجيل الحضور" />
          <NavLink page="reports" iconName="chart" text="عرض التقارير" />
          <NavLink page="settings" iconName="cog" text="الإعدادات" />
        </nav>
      </div>
    </header>
  );
};