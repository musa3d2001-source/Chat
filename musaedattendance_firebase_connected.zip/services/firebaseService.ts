
// services/firebaseService.ts

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAqLe-_QL8_uoh-xHM_08AmyPLzXdL_Ji8",
  authDomain: "attendance-43ecf.firebaseapp.com",
  projectId: "attendance-43ecf",
  storageBucket: "attendance-43ecf.firebasestorage.app",
  messagingSenderId: "1059031805665",
  appId: "1:1059031805665:web:a54a0329654c9f5f1f51a0",
  measurementId: "G-F1JEGP0PM3"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

export { db, auth };
