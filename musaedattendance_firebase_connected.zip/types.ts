export enum AttendanceStatus {
  Present = 'حاضر',
  Absent = 'غائب',
  Late = 'متأخر',
}

export interface Student {
  id: string;
  name: string;
  grade: string;
  classroom: string;
}

export interface AttendanceRecord {
  id: string; // unique id for the record
  date: string; // YYYY-MM-DD
  grade: string;
  classroom: string;
  period: number;
  studentId: string;
  studentName: string;
  status: AttendanceStatus;
  timestamp: number;
  teacherName?: string; // Optional field for the teacher's name
}