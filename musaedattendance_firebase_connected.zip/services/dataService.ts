
// services/dataService.ts
import { collection, addDoc, getDocs, updateDoc, doc } from "firebase/firestore";
import { db } from "./firebaseService";

const attendanceCollection = collection(db, "attendance");

export async function saveAttendanceRecord(record: any) {
  try {
    await addDoc(attendanceCollection, record);
  } catch (error) {
    console.error("Error saving attendance record:", error);
  }
}

export async function fetchAttendanceRecords() {
  try {
    const snapshot = await getDocs(attendanceCollection);
    return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error("Error fetching attendance records:", error);
    return [];
  }
}

export async function updateAttendanceRecord(id: string, data: any) {
  try {
    const recordRef = doc(db, "attendance", id);
    await updateDoc(recordRef, data);
  } catch (error) {
    console.error("Error updating attendance record:", error);
  }
}
