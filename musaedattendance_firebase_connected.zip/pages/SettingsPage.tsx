import React, { useState, useMemo } from 'react';
import { useAttendanceData } from '../hooks/useAttendanceData';
import type { Student } from '../types';
import { GRADES, CLASSROOMS, INITIAL_STUDENTS_DATA } from '../constants';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { SelectInput } from '../components/SelectInput';
import { TextInput } from '../components/TextInput';
import { Icon } from '../components/Icon';
import { Modal } from '../components/Modal';

const emptyStudentForm = { id: '', name: '', grade: '', classroom: '' };

export const SettingsPage: React.FC = () => {
    const { students, addStudent, updateStudent, deleteStudent, isLoading, error, importStudents } = useAttendanceData();
    const [filter, setFilter] = useState({ grade: '', classroom: '' });
    const [newStudent, setNewStudent] = useState<Student>(emptyStudentForm);
    const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
    const [isAdding, setIsAdding] = useState(false);
    const [isUpdating, setIsUpdating] = useState(false);
    const [isSeeding, setIsSeeding] = useState(false);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [studentToEdit, setStudentToEdit] = useState<Student | null>(null);

    const filteredStudents = useMemo(() => {
        return students
            .filter(s => (!filter.grade || s.grade === filter.grade) && (!filter.classroom || s.classroom === filter.classroom))
            .sort((a,b) => a.name.localeCompare(b.name));
    }, [students, filter]);

    const handleNewStudentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setNewStudent(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleAddStudent = async (e: React.FormEvent) => {
        e.preventDefault();
        setMessage(null);
        if (!newStudent.id || !newStudent.name || !newStudent.grade || !newStudent.classroom) {
            setMessage({ type: 'error', text: 'يرجى ملء جميع الحقول لإضافة طالب جديد.' });
            return;
        }
        setIsAdding(true);
        try {
            await addStudent(newStudent);
            setMessage({ type: 'success', text: `تمت إضافة الطالب "${newStudent.name}" بنجاح.` });
            setNewStudent(emptyStudentForm);
        } catch (error) {
            setMessage({ type: 'error', text: (error as Error).message });
        } finally {
            setIsAdding(false);
        }
    };
    
    const openEditModal = (student: Student) => {
        setStudentToEdit(JSON.parse(JSON.stringify(student))); // Deep copy to avoid direct state mutation
        setIsModalOpen(true);
    };

    const handleUpdateStudent = async () => {
        if (!studentToEdit) return;
        setIsUpdating(true);
        try {
            await updateStudent(studentToEdit.id, {
                name: studentToEdit.name,
                grade: studentToEdit.grade,
                classroom: studentToEdit.classroom
            });
            setMessage({ type: 'success', text: `تم تحديث بيانات الطالب "${studentToEdit.name}" بنجاح.` });
            setIsModalOpen(false);
            setStudentToEdit(null);
        } catch (error) {
            setMessage({ type: 'error', text: (error as Error).message });
        } finally {
            setIsUpdating(false);
        }
    };

    const handleSeedData = async () => {
        if (window.confirm("هل أنت متأكد من رغبتك في إضافة قائمة الطلاب الأولية؟ ستتم إضافة 14 طالبًا كبداية.")) {
            setIsSeeding(true);
            try {
                await importStudents(INITIAL_STUDENTS_DATA);
                setMessage({ type: 'success', text: 'تمت إضافة البيانات الأولية بنجاح.' });
            } catch (error) {
                setMessage({ type: 'error', text: 'فشل في إضافة البيانات الأولية.' });
                console.error(error);
            } finally {
                setIsSeeding(false);
            }
        }
    }

    if (isLoading) {
      return <div className="text-center p-10 font-semibold text-gray-600">جاري تحميل بيانات الطلاب...</div>;
    }
  
    if (error) {
        return <div className="text-center p-10 font-bold text-red-600 bg-red-50 rounded-lg">{error}</div>;
    }

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-800">الإعدادات وإدارة الطلاب</h1>

            {message && (
                <div className={`p-4 rounded-md text-sm font-semibold text-center ${message.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {message.text}
                </div>
            )}

            {!isLoading && students.length === 0 && (
                <Card>
                    <div className="text-center">
                        <h3 className="text-lg font-semibold text-gray-700">قاعدة بيانات الطلاب فارغة</h3>
                        <p className="text-gray-500 mt-2 mb-4">يمكنك البدء بإضافة الطلاب يدوياً من النموذج أدناه، أو إضافة قائمة طلاب أولية كمثال للبدء.</p>
                        <Button onClick={handleSeedData} isLoading={isSeeding} variant="secondary">
                           <Icon name="list" className="w-5 h-5" />
                           إضافة بيانات الطلاب الأولية
                        </Button>
                    </div>
                </Card>
            )}
            
            <Card>
                <form onSubmit={handleAddStudent} className="space-y-4">
                    <h2 className="text-xl font-bold text-gray-800">إضافة طالب جديد</h2>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
                        <TextInput label="الرقم التعريفي" name="id" value={newStudent.id} onChange={handleNewStudentChange} placeholder="مثال: 6-1-04" required />
                        <TextInput label="اسم الطالب" name="name" value={newStudent.name} onChange={handleNewStudentChange} placeholder="الاسم الكامل" required />
                        <SelectInput label="الصف" name="grade" value={newStudent.grade} onChange={handleNewStudentChange} options={GRADES.map(g => ({ value: g, label: g }))} required />
                        <SelectInput label="الفصل" name="classroom" value={newStudent.classroom} onChange={handleNewStudentChange} options={CLASSROOMS.map(c => ({ value: c, label: c }))} required />
                        <Button type="submit" variant="primary" isLoading={isAdding}>إضافة الطالب</Button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-bold text-gray-800 mb-4">قائمة الطلاب الحالية ({students.length})</h2>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                    <SelectInput label="تصفية حسب الصف" value={filter.grade} onChange={e => setFilter(f => ({...f, grade: e.target.value, classroom: ''}))} options={[{value: '', label: 'الكل'}, ...GRADES.map(g => ({ value: g, label: g }))]} />
                    <SelectInput label="تصفية حسب الفصل" value={filter.classroom} onChange={e => setFilter(f => ({...f, classroom: e.target.value}))} options={[{value: '', label: 'الكل'}, ...CLASSROOMS.map(c => ({ value: c, label: c }))]} />
                 </div>
                 <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
                    {filteredStudents.length > 0 ? filteredStudents.map(student => (
                        <div key={student.id} className="flex items-center justify-between p-3 bg-white border rounded-lg shadow-sm hover:bg-gray-50">
                            <div>
                                <p className="font-semibold text-gray-800">{student.name}</p>
                                <p className="text-sm text-gray-500">{student.id} | {student.grade} / فصل {student.classroom}</p>
                            </div>
                            <div className="flex items-center gap-2">
                                <Button variant="secondary" onClick={() => openEditModal(student)} className="!p-2">
                                    <Icon name="pencil" className="w-4 h-4" />
                                </Button>
                                <Button variant="danger" onClick={() => deleteStudent(student.id)} className="!p-2">
                                    <Icon name="trash" className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>
                    )) : <p className="text-center text-gray-500 p-8">لا يوجد طلاب يطابقون معايير التصفية. يمكنك إضافة طلاب من النموذج أعلاه.</p>}
                 </div>
            </Card>

            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="تعديل بيانات الطالب">
                {studentToEdit && (
                    <div className="space-y-4">
                        <TextInput label="الرقم التعريفي" value={studentToEdit.id} disabled />
                        <TextInput label="اسم الطالب" value={studentToEdit.name} onChange={e => setStudentToEdit(s => s ? {...s, name: e.target.value} : null)} />
                        <SelectInput label="الصف" value={studentToEdit.grade} onChange={e => setStudentToEdit(s => s ? {...s, grade: e.target.value} : null)} options={GRADES.map(g => ({ value: g, label: g }))} />
                        <SelectInput label="الفصل" value={studentToEdit.classroom} onChange={e => setStudentToEdit(s => s ? {...s, classroom: e.target.value} : null)} options={CLASSROOMS.map(c => ({ value: c, label: c }))} />
                        <div className="flex justify-end gap-2 pt-4">
                            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>إلغاء</Button>
                            <Button variant="primary" onClick={handleUpdateStudent} isLoading={isUpdating}>حفظ التغييرات</Button>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
};