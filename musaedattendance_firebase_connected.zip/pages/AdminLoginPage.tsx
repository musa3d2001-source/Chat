import React, { useState } from 'react';
import { ADMIN_PASSWORD } from '../constants';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { Icon } from '../components/Icon';

interface AdminLoginPageProps {
  onLoginSuccess: () => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onLoginSuccess }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate a small delay for better UX
    setTimeout(() => {
      if (password === ADMIN_PASSWORD) {
        onLoginSuccess();
      } else {
        setError('كلمة المرور غير صحيحة. يرجى المحاولة مرة أخرى.');
        setIsLoading(false);
      }
    }, 500);
  };

  return (
    <div className="flex-grow flex items-center justify-center bg-gray-100">
      <div className="w-full max-w-md mx-auto p-4">
        <Card className="shadow-2xl">
          <div className="text-center mb-6">
            <div className="bg-blue-600 p-3 rounded-full inline-block mb-4">
              <Icon name="cog" className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">دخول المسؤول</h1>
            <p className="text-gray-500 text-sm">يرجى إدخال كلمة المرور للوصول إلى لوحة التحكم.</p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="password" className="sr-only">كلمة المرور</label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm text-center"
                placeholder="كلمة المرور"
              />
            </div>
            {error && <p className="text-red-600 text-sm text-center">{error}</p>}
            <div>
              <Button type="submit" className="w-full" isLoading={isLoading} disabled={isLoading}>
                تسجيل الدخول
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};
