

import { GoogleGenAI } from "@google/genai";
import type { AttendanceRecord } from '../types';

// Per guidelines, assume API_KEY is always available from process.env.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateAttendanceSummary = async (records: AttendanceRecord[]): Promise<string> => {
  if (records.length === 0) {
    return "لا توجد بيانات حضور لتحليلها.";
  }

  const dataSummary = records.map(r => 
    `الطالب: ${r.studentName}, الصف: ${r.grade}-${r.classroom}, التاريخ: ${r.date}, الحصة: ${r.period}, الحالة: ${r.status}, سجل بواسطة: ${r.teacherName || 'غير محدد'}`
  ).join('\n');

  const prompt = `
    أنت محلل بيانات خبير في شؤون الطلاب ومساعد لمدير مدرسة. مهمتك هي تحليل بيانات الحضور والغياب التالية وتقديم تقرير تحليلي دقيق ومفصل باللغة العربية.
    
    البيانات:
    ${dataSummary}

    المطلوب منك التركيز على التفاصيل الدقيقة وتقديم رؤى قابلة للتنفيذ، مع تنظيم التقرير كما يلي:
    1.  **ملخص إحصائي عام:** ابدأ بنظرة عامة على الأرقام: إجمالي السجلات، نسبة الحضور، الغياب، والتأخير.
    2.  **تحليل مفصل حسب الصفوف:** قم بتنظيم تحليلك حسب الصفوف والفصول. لكل صف وفصل، اذكر الطلاب الأكثر غيابًا وأي أنماط ملحوظة (مثلاً، غياب مستمر في حصص معينة).
    3.  **قائمة الطلاب الأكثر غيابًا (بشكل عام):** بعد التحليل المفصل، قدم قائمة موجزة بالطلاب الأكثر غيابًا على مستوى المدرسة (أكثر من مرتين) مع ذكر صفهم لتسهيل المتابعة.
    4.  **توصيات وإجراءات:** بناءً على تحليلك، اقترح إجراءات محددة وواضحة. مثال: "التواصل مع المرشد الطلابي لمتابعة حالة الطالب [اسم الطالب] من الصف [اسم الصف] بسبب غيابه المتكرر في مادة الرياضيات". اذكر اسم المعلم الذي سجل الحالات إذا كان ذلك يضيف سياقًا مهمًا.
    
    اجعل التقرير احترافيًا، ومنظمًا حسب الأقسام المذكورة أعلاه، وسهل القراءة.
    `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "عذرًا، حدث خطأ أثناء إنشاء ملخص الذكاء الاصطناعي. يرجى المحاولة مرة أخرى.";
  }
};