
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import AttendancePage from './pages/AttendancePage';
import LoginPage from './pages/LoginPage';
import AdminPage from './pages/AdminPage';

const App = () => {
  return (
    <Router>
      <nav style={{ padding: '10px', background: '#f0f0f0' }}>
        <Link to="/attendance" style={{ margin: '0 10px' }}>📋 تسجيل الحضور</Link>
        <Link to="/admin" style={{ margin: '0 10px' }}>🛠️ لوحة الإدارة</Link>
        <Link to="/login" style={{ margin: '0 10px' }}>🔐 دخول المعلم</Link>
      </nav>
      <Routes>
        <Route path="/attendance" element={<AttendancePage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/" element={<LoginPage />} />
      </Routes>
    </Router>
  );
};

export default App;
