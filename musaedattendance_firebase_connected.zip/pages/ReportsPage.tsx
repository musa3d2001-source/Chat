import React, { useState, useMemo, useEffect, useRef } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useAttendanceData } from '../hooks/useAttendanceData';
import { generateAttendanceSummary } from '../services/geminiService';
import type { AttendanceRecord, Student } from '../types';
import { AttendanceStatus } from '../types';
import { GRADES, CLASSROOMS, PERIODS } from '../constants';
import { Card } from '../components/Card';
import { SelectInput } from '../components/SelectInput';
import { Button } from '../components/Button';
import { Icon } from '../components/Icon';

const getWeekNumber = (d: Date): number => {
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return weekNo;
};

const exportToCsv = (filename: string, rows: (string | number)[][]) => {
    const processRow = (row: (string|number)[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null || row[j] === undefined ? '' : String(row[j]);
            if (String(row[j]).includes(',')) {
                innerValue = '"' + innerValue + '"';
            }
            if (j > 0)
                finalVal += ',';
            finalVal += innerValue;
        }
        return finalVal + '\n';
    };

    let csvFile = '';
    for (let i = 0; i < rows.length; i++) {
        csvFile += processRow(rows[i]);
    }

    const blob = new Blob([`\uFEFF${csvFile}`], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}


export const ReportsPage: React.FC = () => {
  const { getAttendanceRecords, importStudents, getStudentById, isLoading: isDataLoading, error: dataError } = useAttendanceData();
  const [allRecords, setAllRecords] = useState<AttendanceRecord[]>([]);
  
  // This effect will run whenever getAttendanceRecords function reference changes, or on initial load.
  // It's a way to sync the local state with the hook's state.
  useEffect(() => {
    setAllRecords(getAttendanceRecords());
  }, [getAttendanceRecords]); 

  const [filter, setFilter] = useState({
    grade: '',
    classroom: '',
    timeRange: 'weekly',
  });
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [aiSummary, setAiSummary] = useState('');
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredRecords = useMemo(() => {
    const now = new Date();
    return allRecords.filter(record => {
      const recordDate = new Date(record.date);
      let timeMatch = false;
      if (filter.timeRange === 'daily') timeMatch = recordDate.toDateString() === now.toDateString();
      else if (filter.timeRange === 'weekly') timeMatch = getWeekNumber(recordDate) === getWeekNumber(now) && recordDate.getFullYear() === now.getFullYear();
      else if (filter.timeRange === 'monthly') timeMatch = recordDate.getMonth() === now.getMonth() && recordDate.getFullYear() === now.getFullYear();
      else timeMatch = true; // 'all'

      const gradeMatch = !filter.grade || record.grade === filter.grade;
      const classroomMatch = !filter.classroom || record.classroom === filter.classroom;
      return timeMatch && gradeMatch && classroomMatch;
    });
  }, [allRecords, filter]);

  const stats = useMemo(() => {
    const total = filteredRecords.length;
    if (total === 0) return { total: 0, present: 0, absent: 0, late: 0, presentPercent: 0 };
    const present = filteredRecords.filter(r => r.status === AttendanceStatus.Present).length;
    const absent = filteredRecords.filter(r => r.status === AttendanceStatus.Absent).length;
    const late = filteredRecords.filter(r => r.status === AttendanceStatus.Late).length;
    const presentPercent = total > 0 ? Math.round(((present + late) / total) * 100) : 0;
    return { total, present, absent, late, presentPercent };
  }, [filteredRecords]);

  const frequentAbsentees = useMemo(() => {
    const absenteeCounts = new Map<string, { name: string, count: number }>();
    filteredRecords.forEach(record => {
      if (record.status === AttendanceStatus.Absent) {
        const existing = absenteeCounts.get(record.studentId) || { name: record.studentName, count: 0 };
        existing.count++;
        absenteeCounts.set(record.studentId, existing);
      }
    });
    return Array.from(absenteeCounts.entries())
      .filter(([, data]) => data.count > 1)
      .sort((a, b) => b[1].count - a[1].count)
      .map(([studentId, data]) => ({ studentId, ...data }));
  }, [filteredRecords]);

  const dailySummary = useMemo(() => {
    const summary = new Map<number, { present: number, absent: number, late: number, absentees: string[] }>();
    PERIODS.forEach(p => summary.set(p, { present: 0, absent: 0, late: 0, absentees: [] }));
    
    const today = new Date().toISOString().split('T')[0];
    const todayRecords = allRecords.filter(r => r.date === today && (!filter.grade || r.grade === filter.grade) && (!filter.classroom || r.classroom === filter.classroom));

    todayRecords.forEach(record => {
      const periodSummary = summary.get(record.period);
      if (periodSummary) {
        if (record.status === AttendanceStatus.Present) periodSummary.present++;
        else if (record.status === AttendanceStatus.Absent) {
          periodSummary.absent++;
          periodSummary.absentees.push(`${record.studentName} (${record.grade}/${record.classroom})`);
        }
        else if (record.status === AttendanceStatus.Late) periodSummary.late++;
      }
    });
    return Array.from(summary.entries()).map(([period, data]) => ({ period, ...data }));
  }, [allRecords, filter.grade, filter.classroom]);

  const detailedAbsences = useMemo(() => {
    const absentRecords = filteredRecords.filter(r => r.status === AttendanceStatus.Absent);

    const grouped = absentRecords.reduce((acc, record) => {
        const { grade, classroom, studentId, studentName, date, period } = record;

        if (!acc[grade]) acc[grade] = {};
        if (!acc[grade][classroom]) acc[grade][classroom] = {};
        if (!acc[grade][classroom][studentId]) {
            acc[grade][classroom][studentId] = {
                studentName,
                absences: [],
            };
        }
        acc[grade][classroom][studentId].absences.push({ date, period });
        // Sort absences by date and period
        acc[grade][classroom][studentId].absences.sort((a, b) => {
            const dateComparison = a.date.localeCompare(b.date);
            if (dateComparison !== 0) return dateComparison;
            return a.period - b.period;
        });

        return acc;
    }, {} as Record<string, Record<string, Record<string, { studentName: string; absences: { date: string; period: number }[] }>>>);

    return grouped;
  }, [filteredRecords]);


  const handleGenerateSummary = async () => {
    setIsLoadingAi(true);
    setAiSummary('');
    const summary = await generateAttendanceSummary(filteredRecords);
    setAiSummary(summary);
    setIsLoadingAi(false);
  };

  const handleExport = () => {
    const rows = [
      ["ID", "التاريخ", "الصف", "الفصل", "الحصة", "رقم الطالب", "اسم الطالب", "الحالة", "وقت التسجيل", "اسم المعلم"],
      ...filteredRecords.map(r => [
        r.id, r.date, r.grade, r.classroom, r.period, r.studentId, r.studentName, r.status, new Date(r.timestamp).toLocaleString('ar-EG'), r.teacherName || ''
      ])
    ];
    exportToCsv(`attendance_report_${new Date().toISOString().split('T')[0]}.csv`, rows);
  }

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    const reader = new FileReader();
    reader.onload = async (e) => {
        const text = e.target?.result;
        if (typeof text !== 'string') {
            setIsImporting(false);
            return;
        }
        
        try {
            const rows = text.split(/[\r\n]+/).slice(1); // Skip header, handle different line endings
            const newStudents: Student[] = rows
              .map(row => row.trim().split(','))
              .filter(cols => cols.length === 4 && cols[0] && cols[1] && cols[2] && cols[3])
              .map(([id, name, grade, classroom]) => ({
                  id: id.trim(),
                  name: name.trim(),
                  grade: grade.trim(),
                  classroom: classroom.trim()
              }));
            
            if (newStudents.length > 0) {
              const { success, duplicates } = await importStudents(newStudents);
              alert(`اكتمل الاستيراد. \nتمت إضافة ${success} طالبًا جديدًا إلى قاعدة البيانات. \nتم العثور على ${duplicates} طالبًا مكررًا وتجاهلهم.`);
            } else {
              alert("لم يتم العثور على بيانات طلاب صالحة في الملف. يرجى التحقق من التنسيق: id,name,grade,classroom");
            }

        } catch (error) {
            alert("حدث خطأ أثناء معالجة الملف.");
            console.error("CSV Import Error:", error);
        } finally {
            setIsImporting(false);
        }
    };
    reader.readAsText(file, 'UTF-8');
    event.target.value = ''; // Reset file input
  };
  
  const selectedStudent = useMemo(() => {
    if (!selectedStudentId) return null;
    return getStudentById(selectedStudentId);
  }, [selectedStudentId, getStudentById]);

  const selectedStudentHistory = useMemo(() => {
     if (!selectedStudentId) return [];
     return allRecords.filter(r => r.studentId === selectedStudentId).sort((a,b) => b.timestamp - a.timestamp);
  }, [selectedStudentId, allRecords]);

  const selectedStudentStats = useMemo(() => {
    const total = selectedStudentHistory.length;
    if (total === 0) return { total: 0, present: 0, absent: 0, late: 0 };
    const present = selectedStudentHistory.filter(r => r.status === AttendanceStatus.Present).length;
    const absent = selectedStudentHistory.filter(r => r.status === AttendanceStatus.Absent).length;
    const late = selectedStudentHistory.filter(r => r.status === AttendanceStatus.Late).length;
    return { total, present, absent, late };
  }, [selectedStudentHistory]);
  
  if (isDataLoading) {
      return <div className="text-center p-10 font-semibold text-gray-600">جاري تحميل بيانات الطلاب والسجلات...</div>;
  }
  
  if (dataError) {
      return <div className="text-center p-10 font-bold text-red-600 bg-red-50 rounded-lg">{dataError}</div>;
  }


  return (
    <div className="space-y-6">
        {/* --- Student Detail View --- */}
        {selectedStudent && (
            <Card>
                 <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-gray-800">
                        سجل الطالب: {selectedStudent.name} ({selectedStudent.grade} / فصل {selectedStudent.classroom})
                    </h2>
                    <Button onClick={() => setSelectedStudentId(null)} variant="secondary">إغلاق</Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-1">
                        <h3 className="font-bold mb-2">إحصائيات</h3>
                        <div className="flex justify-around p-4 bg-gray-50 rounded-lg">
                           <div className="text-center"><div className="text-2xl font-bold text-green-600">{selectedStudentStats.present}</div><div className="text-xs text-gray-500">حاضر</div></div>
                           <div className="text-center"><div className="text-2xl font-bold text-yellow-600">{selectedStudentStats.late}</div><div className="text-xs text-gray-500">متأخر</div></div>
                           <div className="text-center"><div className="text-2xl font-bold text-red-600">{selectedStudentStats.absent}</div><div className="text-xs text-gray-500">غائب</div></div>
                        </div>
                    </div>
                    <div className="md:col-span-2">
                        <h3 className="font-bold mb-2">سجل الحضور</h3>
                        <div className="max-h-64 overflow-y-auto space-y-2 pr-2">
                           {selectedStudentHistory.length > 0 ? selectedStudentHistory.map(rec => (
                               <div key={rec.id} className="text-sm p-2 bg-gray-50 rounded flex justify-between">
                                   <span>{rec.date} - الحصة {rec.period}</span>
                                   <span className={`font-bold ${rec.status === AttendanceStatus.Absent ? 'text-red-500' : rec.status === AttendanceStatus.Late ? 'text-yellow-600' : 'text-green-500'}`}>{rec.status}</span>
                               </div>
                           )) : <p className="text-gray-500">لا يوجد سجلات حضور لهذا الطالب.</p>}
                        </div>
                    </div>
                </div>
            </Card>
        )}

      {/* --- Main Dashboard (hidden when student detail is open) --- */}
      <div className={selectedStudentId ? 'hidden' : 'space-y-6'}>
          <Card>
            <div className="flex flex-wrap justify-between items-start gap-4">
              <div>
                  <h2 className="text-xl font-bold mb-4 text-gray-800">فلترة التقارير</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    <SelectInput label="الصف" value={filter.grade} onChange={e => setFilter(f => ({...f, grade: e.target.value}))} options={GRADES.map(g => ({ value: g, label: g }))} />
                    <SelectInput label="الفصل" value={filter.classroom} onChange={e => setFilter(f => ({...f, classroom: e.target.value}))} options={CLASSROOMS.map(s => ({ value: s, label: `فصل ${s}` }))} />
                    <SelectInput label="النطاق الزمني" value={filter.timeRange} onChange={e => setFilter(f => ({...f, timeRange: e.target.value}))} options={[
                      {value: 'daily', label: 'يومي'}, {value: 'weekly', label: 'أسبوعي'}, {value: 'monthly', label: 'شهري'}, {value: 'all', label: 'الكل'}
                    ]}/>
                  </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 pt-10">
                 <input type="file" ref={fileInputRef} onChange={handleFileImport} className="hidden" accept=".csv" />
                 <Button onClick={handleImportClick} variant='secondary' isLoading={isImporting}>استيراد الطلاب (CSV)</Button>
                 <Button onClick={handleExport} disabled={filteredRecords.length === 0}>تصدير (CSV)</Button>
              </div>
            </div>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="text-center"><div className="text-3xl font-bold text-blue-600">{stats.presentPercent}%</div><div className="text-gray-500">نسبة الحضور</div></Card>
              <Card className="text-center"><div className="text-3xl font-bold text-green-600">{stats.present}</div><div className="text-gray-500">حاضر</div></Card>
              <Card className="text-center"><div className="text-3xl font-bold text-yellow-600">{stats.late}</div><div className="text-gray-500">متأخر</div></Card>
              <Card className="text-center"><div className="text-3xl font-bold text-red-600">{stats.absent}</div><div className="text-gray-500">غائب</div></Card>
          </div>
          
          <Card>
            <h2 className="text-xl font-bold mb-4 text-gray-800">تقرير الغياب المفصل</h2>
            {Object.keys(detailedAbsences).length > 0 ? (
                <div className="space-y-6">
                    {Object.entries(detailedAbsences).map(([grade, classrooms]) => (
                        <div key={grade}>
                            <h3 className="text-lg font-bold bg-gray-100 p-2 rounded-t-md">الصف: {grade}</h3>
                            <div className="space-y-4 p-4 border border-t-0 rounded-b-md border-gray-200">
                                {Object.keys(classrooms).length > 0 ? Object.entries(classrooms).map(([classroom, students]) => (
                                    <div key={classroom}>
                                        <h4 className="font-semibold text-md text-gray-700">فصل: {classroom}</h4>
                                        <ul className="mt-2 space-y-2 pr-4">
                                            {Object.entries(students).map(([studentId, data]) => (
                                                <li key={studentId} className="text-sm">
                                                    <span className="font-semibold">{data.studentName}:</span>
                                                    <span className="text-gray-600 mr-2">
                                                        غائب في: {data.absences.map(a => `${a.date} (الحصة ${a.period})`).join('، ')}
                                                    </span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )) : <p className="text-gray-500">لا يوجد غياب مسجل لهذا الصف.</p>}
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-center text-gray-400 p-8">لا توجد سجلات غياب لعرضها حسب الفلترة الحالية.</p>
            )}
          </Card>


          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <h2 className="text-xl font-bold mb-4 text-gray-800">ملخص غياب اليوم</h2>
                <p className="text-sm text-gray-500 mb-2">يعرض هذا الملخص بيانات الغياب لليوم الحالي فقط (الفلترة حسب الصف والفصل تؤثر هنا).</p>
                <div className="space-y-2 max-h-80 overflow-y-auto">
                    {dailySummary.filter(p => p.present + p.absent + p.late > 0).length > 0 ? dailySummary.map(p => (
                        (p.present + p.absent + p.late > 0) &&
                        <div key={p.period} className="p-2 bg-gray-50 rounded">
                            <p className="font-bold">الحصة {p.period}: <span className="text-red-600">{p.absent} غياب</span></p>
                            {p.absentees.length > 0 && <p className="text-xs text-gray-600">{p.absentees.join(', ')}</p>}
                        </div>
                    )) : <p className="text-center text-gray-400 p-8">لا يوجد سجلات غياب لهذا اليوم حسب الفلترة.</p>}
                </div>
              </Card>

              <Card>
                <h2 className="text-xl font-bold mb-4 text-gray-800">الغياب المتكرر</h2>
                <div className="space-y-2 max-h-80 overflow-y-auto">
                    {frequentAbsentees.length > 0 ? frequentAbsentees.map(s => (
                        <button key={s.studentId} onClick={() => setSelectedStudentId(s.studentId)} className="w-full text-right p-2 bg-yellow-50 rounded hover:bg-yellow-100 flex justify-between items-center transition-colors">
                            <span className="font-semibold">{s.name}</span>
                            <span className="text-sm font-bold text-yellow-800 bg-yellow-200 px-2 py-1 rounded">{s.count} مرات</span>
                        </button>
                    )) : <p className="text-center text-gray-400 p-8">لا يوجد طلاب بغياب متكرر حسب الفلترة الحالية.</p>}
                </div>
              </Card>
          </div>

          <Card>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">تحليل الذكاء الاصطناعي</h2>
              <Button onClick={handleGenerateSummary} isLoading={isLoadingAi} disabled={isLoadingAi || filteredRecords.length === 0}>
                <Icon name="sparkles" className="w-5 h-5"/>
                إنشاء ملخص
              </Button>
            </div>
            {isLoadingAi && <div className="text-center text-gray-500 p-4">جاري تحليل البيانات...</div>}
            {aiSummary && (
                <div className="p-4 bg-blue-50 border-r-4 border-blue-500 text-gray-700 space-y-2 whitespace-pre-wrap">
                    {aiSummary}
                </div>
            )}
          </Card>
      </div>
    </div>
  );
};