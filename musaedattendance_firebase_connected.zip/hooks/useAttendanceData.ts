
// hooks/useAttendanceData.ts
import { useEffect, useState } from "react";
import { fetchAttendanceRecords, saveAttendanceRecord } from "../services/dataService";

export function useAttendanceData() {
  const [attendance, setAttendance] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      const records = await fetchAttendanceRecords();
      setAttendance(records);
      setLoading(false);
    };
    loadData();
  }, []);

  const addRecord = async (record: any) => {
    await saveAttendanceRecord(record);
    setAttendance((prev) => [...prev, record]);
  };

  return { attendance, addRecord, loading };
}
